from models.enumTipoCalificacion import EnumTipoCalificacion
class Atencion:
    def __init__(self ):
        self.__id = 0
        self.__servidor = 0
        self.__fecha = ''
        self.__tiempo = '' 
        self.__motivo = ''
        self.__calificacion = EnumTipoCalificacion

    @property
    def _id(self):
        return self.__id

    @_id.setter
    def _id(self, value):
        self.__id = value

    @property
    def _servidor(self):
        return self.__servidor

    @_servidor.setter
    def _servidor(self, value):
        self.__servidor = value

    @property
    def _fecha(self):
        return self.__fecha

    @_fecha.setter
    def _fecha(self, value):
        self.__fecha = value

    @property
    def _tiempo(self):
        return self.__tiempo

    @_tiempo.setter
    def _tiempo(self, value):
        self.__tiempo = value

    @property
    def _motivo(self):
        return self.__motivo

    @_motivo.setter
    def _motivo(self, value):
        self.__motivo = value

    @property
    def _calificacion(self):
        return self.__calificacion

    @_calificacion.setter
    def _calificacion(self, value):
        self.__calificacion = value

    @property
    def serializable(self):
        return {
            "id": self.__id,
            "fecha": self.__fecha,
            "tiempo": self.__tiempo,
            "motivo": self.__motivo,
            "calificacion": self.__calificacion
        }

    @staticmethod
    def deserializar(data):
        atencion = Atencion()
        atencion._id = data["id"]
        atencion._fecha = data["fecha"]
        atencion._tiempo = data["tiempo"]
        atencion._motivo = data["motivo"]
        atencion._calificacion = data["calificacion"]
        return atencion

    def __str__(self):
        return f"Id: {self.__id}, Fecha: {self.__fecha}, Tiempo: {self.__tiempo}, Motivo: {self.__motivo}, Calificacion: {self.__calificacion}"
