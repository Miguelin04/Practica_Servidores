import enum
class EnumTipoCalificacion(enum.Enum):
    BUENO = 'BUENO'
    REGULAR = 'REGULAR'
    MALO = 'MALO'
    MUYBUENO = 'MUY BUENO'
    EXCELENTE = 'EXCELENTE'

    def getValue(self):
        return self.value