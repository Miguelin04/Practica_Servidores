import sys
sys.path.append('../')
import time
from controls.servidorControl import ServidorControl
from controls.atencionControl import AtencionControl
from controls.tda.linked.linkedList import Linked_List
from controls.tda.queque.queque import Queque

at = AtencionControl()
sc = ServidorControl()

try:

  at._atencion._fecha = "2021-11-01"
  at._atencion._tiempo = "10:00"
  at._atencion._motivo = "Transferencia"
  at._atencion._calificacion = "Excelente"
  inicio = time.time()
  at.save
  fin = time.time()
  print("Tiempo de ejecucion: ", fin - inicio)

  at._atencion._fecha = "2021-11-01"
  at._atencion._tiempo = "10:00"
  at._atencion._motivo = "Reclamo"
  at._atencion._calificacion = "Malo"
  at.save

  at._atencion._fecha = "2021-11-01"
  at._atencion._tiempo = "10:00"
  at._atencion._motivo = "Impuestos"
  at._atencion._calificacion = "Regular"  
  at.save


  sc._servidor._nombre = "Servidor 1"
  sc._servidor._cedula = "123456789"
  sc._servidor._atenciones = at._atencion
  sc.save
  
  sc._servidor._nombre = "Servidor 2"
  sc._servidor._cedula = "123456789"
  sc._servidor._atenciones = at._atencion
  sc.save

  sc._servidor._nombre = "Servidor 3"
  sc._servidor._cedula = "123456789"
  #sc._servidor._atenciones = at._atencion
  sc.save

except Exception as error:
    print(error)

