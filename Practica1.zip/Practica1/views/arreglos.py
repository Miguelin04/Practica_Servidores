import sys
sys.path.append('../')
import time
from controls.arreglos.atencionControl import AtencionControl
from controls.arreglos.servidorControl import ServidorControl

at = AtencionControl()
sc = ServidorControl()
try:
    
  at._atencion._fecha = "2021-11-01"
  at._atencion._tiempo = "10:00"
  at._atencion._motivo = "Transferencia"
  at._atencion._calificacion = "Excelente"
  at.save

  at._atencion._fecha = "2021-11-01"
  at._atencion._tiempo = "10:00"
  at._atencion._motivo = "Reclamo"
  at._atencion._calificacion = "Malo"
  inicio = time.time()
  at.save
  fin = time.time()
  print("Tiempo de ejecucion: ", fin - inicio)
except Exception as error:
    print(error)

