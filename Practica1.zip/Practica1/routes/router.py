from flask import Blueprint, jsonify, abort, request, render_template, redirect 
from controls.servidorControl import ServidorControl
from controls.atencionControl import AtencionControl
from flask_cors import CORS
router = Blueprint('router', __name__)


#GET es para presentar datos
#POST guardar datos, modificar datos y el inicio de sesion
#
@router.route('/')
def home():
    return render_template("index.html")

#VER LISTA DE ATENCIONES
@router.route('/servidor/atenciones')
def lista_Atenciones():
    at = AtencionControl()
    return render_template("/servidor/atenciones.html", lista=at.to_dict())

#VER  LISTA SERVIDORES
@router.route('/servidor/servidores')
def lista_Servidores():
    sc = ServidorControl()
    return render_template("/servidor/servidor.html", lista=sc.to_dict())

#REGISTRAR ATENCION
@router.route('/servidor/registrar')
def registar_atencion():
    at = AtencionControl()
    return render_template("/servidor/guardar.html", lista=at.to_dict())

#EDITAR ATENCION
@router.route('/servidor/editar/<pos>')
def ver_editar(pos):
    at = AtencionControl()
    nene = at._list().get(int(pos) - 1)
    return render_template("servidor/editar.html", data=nene)

#EDITAR SERVIODR
@router.route('/servidor/editarS/<pos>')
def editar(pos):
    sc = ServidorControl()
    nene = sc._list().get(int(pos) - 1)
    return render_template("servidor/editServidor.html", data=nene)

#GUARDAR ATENCION
@router.route('/servidor/guardar', methods=["POST"])
def guardar_atencion():
    at = AtencionControl()
    data = request.form
    if not "motivo" in data.keys():
        abort(400)
    at._atencion._calificacion = data["calificacion"]
    at._atencion._fecha = data["fecha"]
    at._atencion._motivo = data["motivo"]
    at._atencion._tiempo = data["tiempo"]
    at.save
    return redirect("/servidor/servidores", code=302)


#MODIFICAR ATENCION
@router.route('/servidor/modificar', methods=["POST"])
def modificar_atenciones():
    at = AtencionControl()
    data = request.form
    pos = request.form["id"]
    nene = at._list().get(int(pos) - 1)
    if not "calificacion" in data.keys():
        abort(400)
        
    #TODO ...Validar
    at._atencion = nene 
    at._atencion._calificacion = data["calificacion"]
    at._atencion._fecha = data["fecha"]
    at._atencion._motivo = data["motivo"]
    at._atencion._tiempo = data["tiempo"]
    at.merge(int(pos) - 1)
    return redirect("/servidor/atenciones", code=302)

#MODIFICAR SERVIDOR

#MODIFICAR ATENCION
@router.route('/servidor/modificarS', methods=["POST"])
def modificar_servidor():
    sc = ServidorControl()
    data = request.form
    pos = request.form["id"]
    nene = sc._list().get(int(pos) - 1)
    if not "nombre" in data.keys():
        abort(400)
        
    #TODO ...Validar
    sc._servidor = nene 
    sc._servidor._nombre = data["nombre"]
    sc._servidor._cedula = data["cedula"]
    sc.merge(int(pos) - 1)
    return redirect("/servidor/servidores", code=302)

@router.route('/servidor/eliminar', methods=["POST"])
def eliminar_atenciones():
    at = AtencionControl()
    pos = request.form["id"]
    at._delete(int(pos))
    return redirect("/servidor/atenciones", code=302)

@router.route('/servidor/eliminarS', methods=["POST"])
def eliminar_servidor():
    at = AtencionControl()
    pos = request.form["id"]
    at._delete(int(pos))
    return redirect("/servidor/atenciones", code=302)