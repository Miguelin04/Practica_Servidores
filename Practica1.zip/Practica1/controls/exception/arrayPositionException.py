class ArrayPositionException(Exception):
    pass