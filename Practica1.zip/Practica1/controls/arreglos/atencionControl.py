from typing import Type
from controls.dao.daoAdapter import DaoAdapter
from models.atencion import Atencion


class AtencionControl(DaoAdapter):
    def __init__(self):
        super().__init__(Atencion)
        self.__atencion = None
        self.__atenciones = []

    @property
    def _atencion(self):
        if self.__atencion== None:
            self.__atencion = Atencion()
        return self.__atencion

    @_atencion.setter
    def _atencion(self, value):
        self.__atencion = value

    @property
    def _atenciones(self):
        return self.__atenciones

    @_atenciones.setter
    def _atenciones(self, value):
        self.__atenciones = value

    @property
    def save(self):
        self.__atenciones.append(self._atencion)
        self._save(self._atencion)


    def merge(self, pos):
        self.__atenciones[pos] = self._atencion
    
    def delete(self, pos):
        del self.__atenciones[pos]