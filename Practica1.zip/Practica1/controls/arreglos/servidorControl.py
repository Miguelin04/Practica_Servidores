from typing import List
from controls.dao.daoAdapter import DaoAdapter
from models.servidor import Servidor

class ServidorControl(DaoAdapter):
    def __init__(self):
        super().__init__(Servidor)
        self.__servidores = []

    @property
    def _servidores(self) -> List[Servidor]:
        return self.__servidores

    def _get_servidor_by_id(self, servidor_id: int) -> Servidor:
        for servidor in self.__servidores:
            if servidor._id == servidor_id:
                return servidor
        return None
    
    @property
    def save(self, servidor: Servidor):
        servidor._id = len(self.__servidores) + 1
        self._save(servidor)
        self.__servidores.append(servidor)

    def merge(self, servidor: Servidor, pos: int):
        existing_servidor = self._get_servidor_by_id(servidor._id)
        if existing_servidor:
            existing_servidor.merge(servidor)
            self._merge(existing_servidor, pos)

    def delete(self, servidor_id: int):
        existing_servidor = self._get_servidor_by_id(servidor_id)
        if existing_servidor:
            self.__servidores.remove(existing_servidor)
            self._delete(existing_servidor, servidor_id)

