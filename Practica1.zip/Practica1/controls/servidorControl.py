from typing import Type
from controls.dao.daoAdapter import DaoAdapter
from models.servidor import Servidor
class ServidorControl(DaoAdapter):
    def __init__(self):
        super().__init__(Servidor)
        self.__servidor = None

    @property
    def _servidor(self):
        if self.__servidor== None:
            self.__servidor = Servidor()
        return self.__servidor

    @_servidor.setter
    def _servidor(self, value):
        self.__servidor = value

    @property
    def _servidores(self):
        return self.__servidores

    @_servidores.setter
    def _servidores(self, value):
        self.__servidores = value

    @property
    def _lista(self):
        return self._list()

    @property
    def save(self):
        self._servidor._id = self._lista._lenght + 1
        self._save(self._servidor)
    
    def merge(self, pos):
        self._merge(self._servidor, pos)
    
    def delete(self, pos):
        self._delete(self._servidor, pos)